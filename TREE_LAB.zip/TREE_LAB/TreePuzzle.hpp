//
//  TreePuzzle.hpp
//  TREE_LAB
//
//  Created by D@ on 10/19/18.
//  Copyright © 2018 Max Luu. All rights reserved.
//

#ifndef TreePuzzle_hpp
#define TreePuzzle_hpp
#include <stdlib.h>
#include <string.h>
#include "BSTY.hpp"

class treePuzzle {
    BSTY *tree;
public:
    treePuzzle(int x, string sarr[], int k);
    void runMine1(bool flag);
    void runMine2();
    ~treePuzzle();
};
#endif /* TreePuzzle_hpp */
